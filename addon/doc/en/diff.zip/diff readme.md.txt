readme.md
diff between version 1.14 (<) and version 1.15 (>)
This file should not be translated. It is only used for the gitHub repository.
17c17
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/apprentiClavierAccessEnhancement/apprentiClavierAccessEnhancement-1.14.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/apprentiClavierAccessEnhancement/apprentiClavierAccessEnhancement-1.15.nvda-addon
