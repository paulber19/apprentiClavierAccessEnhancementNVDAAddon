readme.md
diff between version 1.13 (<) and version 1.14 (>)
This file should not be translated. It is only used for the gitHub repository.
9,10c9,10
< 	* Minimum required NVDA version:  2024.1
< 	* Last NVDA version tested:  2025.1
---
> 	* Minimum required NVDA version:  2025.1
> 	* Last NVDA version tested:  2026.1
17c17
< [1]: https://rawgit.com/paulber007/AllMyNVDAAddons/master/apprentiClavierAccessEnhancement/apprentiClavierAccessEnhancement-1.13.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/apprentiClavierAccessEnhancement/apprentiClavierAccessEnhancement-1.14.nvda-addon
